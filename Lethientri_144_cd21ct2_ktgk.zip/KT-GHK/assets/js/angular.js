var app = angular.module("myapp", []);
app.controller("myctrl", function ($scope) {});
